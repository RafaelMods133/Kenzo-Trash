// admin.js

// simple helper storage
function storage(key, value) {
  if (value === undefined) {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } else {
    localStorage.setItem(key, JSON.stringify(value));
  }
}

function ensure() {
  if (!storage("kd_data")) storage("kd_data", {
    title: "Kenzo Delicia",
    subtitle: "Community Dashboard",
    heroImage: "assets/banner.png",
    rules: "Peraturan belum diset.",
    notices: [],
    themeColor: "#00e5ff",
    bgImage: "",
    users: [
      {username: "owner", password: "owner123", role: "owner"},
      {username: "reseller", password: "reseller123", role: "reseller"}
    ]
  });
  if (!storage("kd_owner_pass")) {
    // not set yet - keep null so admin shows setup
  }
}

async function hashStr(str) {
  // SHA-256 via SubtleCrypto
  const enc = new TextEncoder();
  const data = enc.encode(str);
  const hash = await crypto.subtle.digest('SHA-256', data);
  const arr = Array.from(new Uint8Array(hash));
  return arr.map(b => b.toString(16).padStart(2, '0')).join('');
}

function renderUserList() {
  const d = storage("kd_data");
  const ul = document.getElementById("admin-user-list");
  ul.innerHTML = "";
  d.users.forEach(u=>{
    const li = document.createElement("li");
    li.innerHTML = `<span>${u.username} <small>(${u.role})</small></span>`;
    const btns = document.createElement("span");
    const del = document.createElement("button");
    del.textContent = "Hapus";
    del.addEventListener("click", ()=>{
      if (!confirm("Hapus akun "+u.username+"?")) return;
      d.users = d.users.filter(x=>x.username !== u.username);
      storage("kd_data", d);
      renderUserList();
    });
    const reset = document.createElement("button");
    reset.textContent = "ResetPass->1234";
    reset.addEventListener("click", ()=>{
      const target = d.users.find(x=>x.username===u.username);
      if (target) {
        target.password = "1234";
        storage("kd_data", d);
        alert("Password direset ke 1234");
      }
    });
    btns.appendChild(reset);
    btns.appendChild(del);
    li.appendChild(btns);
    ul.appendChild(li);
  });
}

function renderNotices() {
  const d = storage("kd_data");
  const ul = document.getElementById("admin-notice-list");
  ul.innerHTML = "";
  (d.notices||[]).forEach((n, idx)=>{
    const li = document.createElement("li");
    li.textContent = n;
    const rem = document.createElement("button");
    rem.textContent = "Hapus";
    rem.addEventListener("click", ()=>{
      d.notices.splice(idx,1);
      storage("kd_data", d);
      renderNotices();
    });
    li.appendChild(rem);
    ul.appendChild(li);
  });
}

function renderAdminValues() {
  const d = storage("kd_data");
  document.getElementById("admin-rules").value = d.rules||"";
  document.getElementById("theme-color").value = d.themeColor || "#00e5ff";
  document.getElementById("bg-url").value = d.bgImage || "";
}

async function initAdmin() {
  ensure();
  document.getElementById("year2").innerText = new Date().getFullYear();
  const ownerPassHash = storage("kd_owner_pass"); // hashed password
  const setupArea = document.getElementById("setup-area");
  const loginArea = document.getElementById("login-area");
  const adminControls = document.getElementById("admin-controls");

  if (!ownerPassHash) {
    setupArea.style.display = "block";
    loginArea.style.display = "none";
    adminControls.style.display = "none";

    document.getElementById("setup-save").addEventListener("click", async ()=>{
      const raw = document.getElementById("setup-pass").value;
      if (!raw || raw.length < 6) return alert("Password minimal 6 karakter");
      const h = await hashStr(raw);
      storage("kd_owner_pass", h);
      alert("Owner password disimpan. Sekarang login di panel.");
      location.reload();
    });
    return;
  } else {
    setupArea.style.display = "none";
    loginArea.style.display = "block";
  }

  document.getElementById("owner-login").addEventListener("click", async ()=>{
    const user = (document.getElementById("owner-username").value || "owner").trim();
    const pass = document.getElementById("owner-pass").value || "";
    const h = await hashStr(pass);
    const stored = storage("kd_owner_pass");
    if (h === stored) {
      // grant access
      loginArea.style.display = "none";
      adminControls.style.display = "block";
      // optionally set currentOwner in session storage
      sessionStorage.setItem("kd_owner_auth","1");
      loadAdmin();
    } else {
      document.getElementById("login-msg").innerText = "Password salah";
    }
  });

  // if already authenticated in this session
  if (sessionStorage.getItem("kd_owner_auth") === "1") {
    loginArea.style.display = "none";
    adminControls.style.display = "block";
    loadAdmin();
  }

  document.getElementById("owner-logout").addEventListener("click", ()=>{
    sessionStorage.removeItem("kd_owner_auth");
    location.reload();
  });
}

function loadAdmin() {
  renderAdminValues();
  renderUserList();
  renderNotices();

  document.getElementById("save-rules").addEventListener("click", ()=>{
    const d = storage("kd_data");
    d.rules = document.getElementById("admin-rules").value;
    storage("kd_data", d);
    alert("Peraturan disimpan.");
  });

  document.getElementById("add-notice").addEventListener("click", ()=>{
    const t = (document.getElementById("notice-text").value || "").trim();
    if (!t) return alert("Isi pengumuman.");
    const d = storage("kd_data");
    d.notices = d.notices || [];
    d.notices.unshift(t);
    storage("kd_data", d);
    document.getElementById("notice-text").value = "";
    renderNotices();
  });

  document.getElementById("save-theme").addEventListener("click", ()=>{
    const color = document.getElementById("theme-color").value;
    const bg = document.getElementById("bg-url").value;
    const d = storage("kd_data");
    d.themeColor = color;
    d.bgImage = bg;
    storage("kd_data", d);
    alert("Tampilan disimpan. Buka ulang index.html untuk melihat perubahan.");
  });

  document.getElementById("reset-theme").addEventListener("click", ()=>{
    const d = storage("kd_data");
    d.themeColor = "#00e5ff";
    d.bgImage = "";
    storage("kd_data", d);
    renderAdminValues();
    alert("Tampilan di-reset.");
  });

  document.getElementById("create-account").addEventListener("click", ()=>{
    const u = (document.getElementById("new-username").value || "").trim();
    const p = document.getElementById("new-password").value || "";
    const r = document.getElementById("new-role").value;
    if (!u || !p) return alert("Isi username & password");
    const d = storage("kd_data");
    if (d.users.find(x=>x.username===u)) return alert("Username sudah ada");
    d.users.push({username:u,password:p,role:r});
    storage("kd_data", d);
    document.getElementById("new-username").value = "";
    document.getElementById("new-password").value = "";
    renderUserList();
  });

}

document.addEventListener("DOMContentLoaded", initAdmin);

// main.js
const DEFAULTS = {
  title: "Kenzo Delicia",
  subtitle: "Community Dashboard",
  heroImage: "assets/banner.png",
  rules: "Peraturan belum diset. Silakan hubungi owner.",
  notices: [],
  themeColor: "#00e5ff",
  bgImage: "",
  users: [
    {username: "owner", password: "owner123", role: "owner"},
    {username: "reseller", password: "reseller123", role: "reseller"}
  ]
};

function storage(key, value) {
  if (value === undefined) {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } else {
    localStorage.setItem(key, JSON.stringify(value));
  }
}

function ensureData() {
  if (!storage("kd_data")) {
    storage("kd_data", DEFAULTS);
  } else {
    // migrate minimal checks
    let d = storage("kd_data");
    if (!d.users) d.users = DEFAULTS.users;
    storage("kd_data", d);
  }
}

function applyTheme(d) {
  if (d.bgImage) document.body.style.backgroundImage = `url('${d.bgImage}')`;
  else document.body.style.backgroundImage = "";
  document.documentElement.style.setProperty('--neon', d.themeColor || DEFAULTS.themeColor);
}

function renderMain() {
  ensureData();
  const d = storage("kd_data");
  document.getElementById("site-title").innerText = d.title || DEFAULTS.title;
  document.getElementById("site-sub").innerText = d.subtitle || DEFAULTS.subtitle;
  document.getElementById("hero-title").innerText = d.title || DEFAULTS.title;
  document.getElementById("hero-sub").innerText = d.subtitle || DEFAULTS.subtitle;
  document.getElementById("hero-img").src = d.heroImage || DEFAULTS.heroImage;
  document.getElementById("rules-content").innerText = d.rules || DEFAULTS.rules;

  const notices = d.notices && d.notices.length ? d.notices : ["Tidak ada pengumuman."];
  const ul = document.getElementById("notice-list");
  ul.innerHTML = "";
  notices.forEach(n=>{
    const li = document.createElement("li");
    li.className = "notice-item";
    li.innerText = n;
    ul.appendChild(li);
  });

  applyTheme(d);
}

function authInit() {
  const loginForm = document.getElementById("login-form");
  const loggedArea = document.getElementById("logged-as");
  const loginArea = document.getElementById("auth-forms");
  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");
  const logoutBtn = document.getElementById("logout-btn");

  function currentUser() {
    return storage("kd_current");
  }

  function showLogged() {
    const cur = currentUser();
    if (cur) {
      document.getElementById("logged-username").innerText = cur.username;
      document.getElementById("logged-role").innerText = cur.role;
      loginForm.style.display = "none";
      loggedArea.style.display = "block";
    } else {
      loginForm.style.display = "block";
      loggedArea.style.display = "none";
    }
  }

  loginForm.addEventListener("submit", e=>{
    e.preventDefault();
    const u = usernameInput.value.trim();
    const p = passwordInput.value;
    const d = storage("kd_data");
    const found = d.users.find(x => x.username === u && x.password === p);
    if (found) {
      storage("kd_current", found);
      showLogged();
      alert("Login berhasil: " + found.username);
    } else {
      alert("Login gagal. Cek username/password.");
    }
  });

  logoutBtn.addEventListener("click", ()=>{
    localStorage.removeItem("kd_current");
    showLogged();
  });

  // init
  showLogged();
}

document.addEventListener("DOMContentLoaded", ()=>{
  if (!localStorage.getItem("kd_data")) storage("kd_data", DEFAULTS);
  document.getElementById("year").innerText = new Date().getFullYear();
  renderMain();
  authInit();
});